// app.jsx — root of the redesigned Scheduling screen.

const { useState, useMemo, useCallback, useEffect, useRef } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "layout": "tight",
  "density": "compact",
  "calendarMode": "drawer",
  "showTopbar": true,
  "viewport": "desk"
}/*EDITMODE-END*/;

const VIEWPORTS = {
  fit:    { label: "Fit window",         width: null, height: null },
  mac13:  { label: '13" MacBook Air',    width: 1280, height: 800 },
  mac14:  { label: '14" MacBook Pro',    width: 1512, height: 945 },
  desk:   { label: "Desktop",            width: 1920, height: 1080 },
  tablet: { label: "Tablet landscape",   width: 1024, height: 768 },
  ipad:   { label: "iPad portrait",      width: 820,  height: 1180 },
  phone:  { label: "Phone",              width: 414,  height: 896 },
};

const INITIAL_FORM = {
  ticketType: "Installation",
  problemCode: "Inverter Setup",
  ticketStatus: "Completed",
  resolution: "Resolved on Site",
  showActive: true,
  assigned: "Ryan Fitzgerald",
  nextDay: true,
  midPoint: false,
  city: "Dallas, TX",
  dateRange: "05/26/2026 - 06/08/2026",
  techSearch: "",
  scope: "Replace damaged microinverter on Array A, panel 14. Verify production curve restored within 24 hours of swap. Reseal flashing if MC4 connectors show moisture.",
  work: "",
  voided: false,
  date: "05/27/2026",
  start: "07:30 AM",
  end: "11:00 AM",
  multiDay: false,
  tz: "America/Chicago",
  office: "Dallas",
  tech: "Ryan Fitzgerald",
};

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [form, setForm] = useState(INITIAL_FORM);
  const [activeTab, setActiveTab] = useState("details");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [isNarrow, setIsNarrow] = useState(false);
  const schedModalRef = useRef(null);
  const [clogOpen, setClogOpen] = useState(false);
  const [clog, setClog] = useState({
    arrived:   { date: "05/26/2026", time: "08:14 AM" },
    departed:  { date: "05/26/2026", time: "12:47 PM" },
    completed: { date: "05/26/2026", time: "12:48 PM" },
  });

  const [calYear, setCalYear] = useState(2026);
  const [calMonth, setCalMonth] = useState(4);
  const [calView, setCalView] = useState("Month");
  const [calSelected, setCalSelected] = useState(new Date(2026, 4, 26));

  const calState = {
    year: calYear, month: calMonth, view: calView,
    selected: calSelected, events: SAMPLE_EVENTS,
  };
  const calActions = {
    onPrev: () => {
      let m = calMonth - 1, y = calYear;
      if (m < 0) { m = 11; y -= 1; }
      setCalMonth(m); setCalYear(y);
    },
    onNext: () => {
      let m = calMonth + 1, y = calYear;
      if (m > 11) { m = 0; y += 1; }
      setCalMonth(m); setCalYear(y);
    },
    onToday: () => { setCalMonth(4); setCalYear(2026); setCalSelected(new Date(2026, 4, 26)); },
    onSelect: (d) => setCalSelected(d),
    onViewChange: (v) => setCalView(v),
  };

  const customer = {
    name: "Maria Mendoza",
    phone: "(469) 583-1892",
    address: "719 S Rosemont Ave, Dallas, TX 75208",
  };

  const onClose = () => alert("Close clicked (prototype)");
  const openCalendar = useCallback(() => setDrawerOpen(true), []);
  const openClog = useCallback(() => setClogOpen(true), []);
  const onSelectTicket = useCallback((ticket) => {
    setForm((f) => ({
      ...f,
      selectedTicketId: ticket.num,
      ticketType: ticket.type,
      problemCode: ticket.problem,
      ticketStatus: ticket.status,
      date: ticket.scheduled !== "-" ? ticket.scheduled : f.date,
    }));
  }, []);

  // Switch to the single-scroll sectioned layout on tablet/phone widths.
  // Uses ResizeObserver layout width (unaffected by the viewport-sim scale
  // transform) so it matches the container-query breakpoint at 820px.
  useEffect(() => {
    const el = schedModalRef.current;
    if (!el) return;
    const measure = (w) => setIsNarrow(w <= 820);
    measure(el.clientWidth);
    const ro = new ResizeObserver((entries) => {
      for (const e of entries) measure(e.contentRect.width);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [t.viewport]);

  const layoutClass = `layout-${t.layout}`;
  // Developer-handoff builds inject window.__FORCED_VIEWPORT to lock the
  // device size; falls through to the in-page tweak otherwise.
  const forcedVp = (typeof window !== "undefined" && window.__FORCED_VIEWPORT) || null;
  const vp = forcedVp || VIEWPORTS[t.viewport] || VIEWPORTS.fit;
  const useVpFrame = vp.width != null;

  const appShell = (
    <div className="app-shell" data-density={t.density}>
      <div className="app-titlebar">
        <h1 className="app-title">
          Scheduling
          <span className="ticket-id">TKT-217</span>
        </h1>
        <button className="close-x close-x-danger" onClick={onClose} aria-label="Close">
          <Icon name="x" size={20}/>
        </button>
      </div>

      <div className="sched-modal" ref={schedModalRef} data-screen-label="Scheduling">
        {isNarrow ? (
          <MobileStack
            form={form} setForm={setForm}
            customer={customer} status={form.ticketStatus}
            onOpenCalendar={openCalendar}
            onOpenCompletionLog={openClog}
            onSelectTicket={onSelectTicket}
          />
        ) : t.layout === "tabbed" ? (
          <TabbedLayout
            form={form} setForm={setForm}
            onOpenCalendar={openCalendar}
            onOpenCompletionLog={openClog}
            onSelectTicket={onSelectTicket}
            customer={customer}
            calendarMode={t.calendarMode}
            calState={calState} calActions={calActions}
          />
        ) : (
          <div className={`sched-body ${layoutClass}`}>
            {t.layout === "twopane" ? (
              <React.Fragment>
                <div className={`col col-meta ${activeTab === "details" ? "col-active" : ""}`}>
                  <TicketMetaBody form={form} setForm={setForm}/>
                </div>
                <div className={`col col-main ${activeTab !== "details" ? "col-active" : ""}`}>
                  <JobColumn form={form} setForm={setForm} onOpenCalendar={openCalendar} onSelectTicket={onSelectTicket} customer={customer} status={form.ticketStatus}/>
                  <div className="divider-line"/>
                  <ScheduleInlineRow form={form} setForm={setForm}/>
                </div>
              </React.Fragment>
            ) : (
              <React.Fragment>
                <div className={`col col-meta ${activeTab === "details" ? "col-active" : ""}`}>
                  <TicketMetaBody form={form} setForm={setForm}/>
                  <div className="divider-line"/>
                  <ScheduleColumn form={form} setForm={setForm} onOpenCalendar={openCalendar} onOpenCompletionLog={openClog}
                    calendarMode={t.calendarMode}
                    calState={calState} calActions={calActions}
                  />
                </div>
                <div className={`col col-main ${activeTab === "job" ? "col-active" : ""}`}>
                  <JobColumn form={form} setForm={setForm} onOpenCalendar={openCalendar} onSelectTicket={onSelectTicket} customer={customer} status={form.ticketStatus}/>
                </div>
              </React.Fragment>
            )}
          </div>
        )}

        {/* Bottom action bar */}
        <div className="action-bar">
          {(isNarrow ? [] : RELATED_LINKS).map((l) => (
            <button key={l.label} className="btn btn-secondary btn-sm related-btn" title={l.label}>
              <Icon name={l.icon} size={11}/>
              {l.label}
            </button>
          ))}
          <div className="ab-spacer"/>
          <Button variant="secondary" icon="check">Save Draft</Button>
          <div className="ab-divider"/>
          <Button variant="secondary" icon="x" onClick={onClose}>Close</Button>
          <Button variant="save" icon="save">Save</Button>
        </div>
      </div>

      {/* Calendar drawer */}
      <div className={`drawer-scrim ${drawerOpen ? "open" : ""}`} onClick={() => setDrawerOpen(false)}/>
      <div className={`drawer ${drawerOpen ? "open" : ""}`}>
        <div className="drawer-head">
          <h2>Team Calendar</h2>
          <span className="sub-meta">Click a date to assign · ESC to close</span>
          <div className="flex-grow-1"/>
          <Button variant="ghost" size="sm" icon="map-pin">Map</Button>
          <Button variant="secondary" size="sm" onClick={() => setDrawerOpen(false)} icon="x">Close</Button>
        </div>
        <div className="drawer-filters">
          <Field label="Office">
            <Select value={form.office} onChange={(v) => setForm({...form, office: v})} options={OFFICES}/>
          </Field>
          <Field label="Tech">
            <Select value={form.tech} onChange={(v) => setForm({...form, tech: v})} options={TECHS}/>
          </Field>
        </div>
        <div className="drawer-body d-flex flex-column">
          <div className="drawer-cal-wrap">
            <Calendar {...calState} {...calActions}/>
          </div>
        </div>
      </div>

      {/* Completion Log modal */}
      <CompletionLogModal
        open={clogOpen}
        onClose={() => setClogOpen(false)}
        value={clog}
        onChange={setClog}
        onSave={() => setClogOpen(false)}
      />

      <TweaksPanel>
        <TweakSection label="Layout"/>
        <TweakRadio label="Layout variant" value={t.layout}
          options={[
            {value: "tight", label: "Tight 3-col"},
            {value: "twopane", label: "Two-pane"},
            {value: "tabbed", label: "Tabbed"},
          ]}
          onChange={(v) => setTweak("layout", v)}/>
        <TweakRadio label="Density" value={t.density}
          options={[
            {value: "compact", label: "Compact"},
            {value: "comfortable", label: "Comfortable"},
          ]}
          onChange={(v) => setTweak("density", v)}/>
        <TweakSection label="Calendar"/>
        <TweakRadio label="Mode" value={t.calendarMode}
          options={[
            {value: "drawer", label: "Drawer"},
            {value: "inline", label: "Inline"},
          ]}
          onChange={(v) => setTweak("calendarMode", v)}/>
        <TweakButton label="Open calendar drawer" onClick={openCalendar}/>
        <TweakSection label="Viewport"/>
        <TweakSelect label="Simulate device" value={t.viewport}
          options={Object.entries(VIEWPORTS).map(([value, v]) => ({
            value,
            label: v.width ? `${v.label} · ${v.width}px` : v.label,
          }))}
          onChange={(v) => setTweak("viewport", v)}/>
        <TweakSection label="Chrome"/>
        <TweakToggle label="Show app top-bar" value={t.showTopbar}
          onChange={(v) => setTweak("showTopbar", v)}/>
      </TweaksPanel>
    </div>
  );

  return useVpFrame ? (
    <ViewportFrame vp={vp}>{appShell}</ViewportFrame>
  ) : appShell;
}

/* ───────────────────────── Viewport simulator frame ─────────────────────────
   Renders children at TRUE device pixel dimensions, then computes a
   transform: scale() to fit the available frame area. */
function ViewportFrame({ vp, children }) {
  const slotRef = useRef(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const el = slotRef.current;
    if (!el) return;
    const compute = () => {
      const rect = el.getBoundingClientRect();
      const padX = 32; // breathing room
      const padY = 16;
      const sx = (rect.width - padX) / vp.width;
      const sy = (rect.height - padY) / vp.height;
      setScale(Math.min(1, sx, sy));
    };
    compute();
    const ro = new ResizeObserver(compute);
    ro.observe(el);
    window.addEventListener("resize", compute);
    return () => { ro.disconnect(); window.removeEventListener("resize", compute); };
  }, [vp.width, vp.height]);

  return (
    <div className="viewport-frame">
      <div className="viewport-bar">
        <span className="label">{vp.label}</span>
        <span className="dim">{vp.width} × {vp.height}</span>
        <span className="vp-sep">·</span>
        <span className="scale-pct">{Math.round(scale * 100)}%</span>
      </div>
      <div className="viewport-slot" ref={slotRef}>
        <div
          className="viewport-shell"
          style={{
            "--vp-width":  vp.width + "px",
            "--vp-height": vp.height + "px",
            "--vp-scale":  scale,
            marginBottom: -(vp.height * (1 - scale)) + "px",
            marginRight:  -(vp.width  * (1 - scale)) / 2 + "px",
            marginLeft:   -(vp.width  * (1 - scale)) / 2 + "px",
          }}
        >
          {children}
        </div>
      </div>
    </div>
  );
}

/* Schedule fields rendered inline (two-pane mode) */
function ScheduleInlineRow({ form, setForm }) {
  return (
    <React.Fragment>
      <Subhead title="Assign Schedule"/>
      <div className="card card-pad">
        <div className="sched-inline-row">
          <Field label="Date">
            <Input value={form.date} onChange={(v) => setForm({...form, date: v})} icon="calendar"/>
          </Field>
          <Field label="Start Time">
            <Input value={form.start} onChange={(v) => setForm({...form, start: v})} icon="clock"/>
          </Field>
          <Field label="End Time">
            <Input value={form.end} onChange={(v) => setForm({...form, end: v})} icon="clock"/>
          </Field>
          <Field label="Time Zone">
            <Select value={form.tz} onChange={(v) => setForm({...form, tz: v})} options={TIME_ZONES}/>
          </Field>
          <Field label="Office">
            <Select value={form.office} onChange={(v) => setForm({...form, office: v})} options={OFFICES}/>
          </Field>
          <Field label="Tech">
            <Select value={form.tech} onChange={(v) => setForm({...form, tech: v})} options={TECHS}/>
          </Field>
        </div>
        <div className="d-flex align-items-center gap-3 mt-3">
          <Check checked={form.multiDay} onChange={(v) => setForm({...form, multiDay: v})} label="Multi-Day Ticket"/>
          <div className="ms-auto">
            <Button variant="primary" icon="calendar">Save &amp; Schedule</Button>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

/* Tabbed layout */
function TabbedLayout({ form, setForm, onOpenCalendar, onOpenCompletionLog, onSelectTicket, calendarMode, calState, calActions, customer }) {
  const [tab, setTab] = useState("ticket");
  return (
    <div className="sched-body layout-tabbed">
      <div className="tabbed-tabbar">
        <Segmented value={tab} onChange={setTab} options={[
          {value: "ticket", label: "Ticket Details"},
          {value: "job", label: "Job & Activity"},
          {value: "schedule", label: "Schedule"},
        ]}/>
      </div>
      <div className="col tabbed-pane">
        {tab === "ticket" && <TicketMetaBody form={form} setForm={setForm}/>}
        {tab === "job" && <JobColumn form={form} setForm={setForm} onOpenCalendar={onOpenCalendar} onSelectTicket={onSelectTicket} customer={customer} status={form.ticketStatus}/>}
        {tab === "schedule" && (
          <ScheduleColumn form={form} setForm={setForm} onOpenCalendar={onOpenCalendar} onOpenCompletionLog={onOpenCompletionLog}
            calendarMode={calendarMode}
            calState={calState} calActions={calActions}/>
        )}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
