// calendar.jsx — month calendar with events. Built for a 13" fit.
// Renders a 6-row grid (35–42 cells) of a calendar month and overlays event chips.

const CAL_DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const CAL_MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

/* Build grid of 42 cells starting Sun-first */
function buildMonthCells(year, month /* 0-indexed */) {
  const first = new Date(year, month, 1);
  const startDay = first.getDay(); // 0 = Sun
  const start = new Date(year, month, 1 - startDay);
  const cells = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    cells.push(d);
  }
  return cells;
}

const sameDay = (a, b) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

const Calendar = ({
  year,
  month,
  events = [],
  view = "Month",
  selected,
  onSelect,
  onPrev,
  onNext,
  onToday,
  onViewChange,
  compact = false,
}) => {
  const today = new Date();
  const cells = buildMonthCells(year, month);

  return (
    <div className={`cal-shell ${compact ? "compact" : ""}`}>
      <div className="cal-head">
        <div className="cal-nav">
          <button onClick={onPrev} aria-label="Previous"><Icon name="chevron-left" size={14}/></button>
          <button onClick={onNext} aria-label="Next"><Icon name="chevron-right" size={14}/></button>
          <button className="today" onClick={onToday}>Today</button>
        </div>
        <div className="cal-month">{CAL_MONTHS[month]} {year}</div>
        {!compact && (
          <Segmented
            value={view}
            onChange={onViewChange || (() => {})}
            options={["Month", "Week", "Day", "List"]}
          />
        )}
      </div>
      <div className="cal-weekdays">
        {CAL_DAYS.map((d) => <div key={d}>{d}</div>)}
      </div>
      <div className="cal-grid">
        {cells.map((d, i) => {
          const inMonth = d.getMonth() === month;
          const isToday = sameDay(d, today);
          const isSelected = selected && sameDay(d, selected);
          const dayEvents = events.filter((e) => sameDay(e.date, d));
          const cls = [
            "cal-cell",
            !inMonth && "outside",
            isToday && "today",
            isSelected && "selected",
            dayEvents.length && "has-events",
          ].filter(Boolean).join(" ");
          return (
            <div
              key={i}
              className={cls}
              onClick={() => onSelect && onSelect(d)}
            >
              <div className="cal-date">{d.getDate()}</div>
              {!compact && dayEvents.slice(0, 3).map((e, j) => (
                <div className="cal-event" key={j} title={e.label}>
                  <span className={`dot ${e.color || ""}`}/>
                  <span>{e.time} {e.label}</span>
                </div>
              ))}
              {!compact && dayEvents.length > 3 && (
                <div className="more">+{dayEvents.length - 3} more</div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ───────────────────────── Sample events ───────────────────────── */
const SAMPLE_EVENTS = [
  // Late April (outside cells)
  { date: new Date(2026, 3, 27), time: "7:30a", label: "Ryan F: Westminster", color: "" },
  { date: new Date(2026, 3, 28), time: "7:30a", label: "Ryan/Chris: Pueblo", color: "" },
  { date: new Date(2026, 3, 28), time: "5:30p", label: "Ryan/Chris: Pueblo", color: "" },
  { date: new Date(2026, 3, 29), time: "7:30a", label: "Ryan F: Denver", color: "" },
  { date: new Date(2026, 3, 29), time: "7:30a", label: "Christopher D: Aurora", color: "" },
  // May
  { date: new Date(2026, 4, 8), time: "6:30a", label: "07:30 AM CDT", color: "blue" },
  { date: new Date(2026, 4, 8), time: "7:30a", label: "Ryan F: Arvada", color: "" },
  { date: new Date(2026, 4, 9), time: "6:30a", label: "07:30 AM CDT", color: "blue" },
  { date: new Date(2026, 4, 9), time: "6:30a", label: "07:30 AM CDT", color: "blue" },
  { date: new Date(2026, 4, 14), time: "7:30a", label: "Ryan F: Arvada", color: "" },
  { date: new Date(2026, 4, 14), time: "9a", label: "Ryan F: Denver", color: "" },
  { date: new Date(2026, 4, 14), time: "12p", label: "Ryan F: Longmont", color: "" },
  { date: new Date(2026, 4, 18), time: "7:30a", label: "Ryan F: Johnstown", color: "" },
  { date: new Date(2026, 4, 18), time: "12p", label: "Ryan F: Longmont", color: "" },
  { date: new Date(2026, 4, 20), time: "7a", label: "(08:00 AM CDT)", color: "" },
  { date: new Date(2026, 4, 20), time: "9:30a", label: "(10:30 AM CDT)", color: "" },
  { date: new Date(2026, 4, 21), time: "8a", label: "Ryan F: Broomfield", color: "" },
  { date: new Date(2026, 4, 22), time: "8a", label: "Ryan F: Broomfield", color: "" },
  { date: new Date(2026, 4, 29), time: "7:30a", label: "Ryan F: Englewood", color: "blue" },
  { date: new Date(2026, 4, 30), time: "7:30a", label: "Ryan F: Englewood", color: "blue" },
];

Object.assign(window, { Calendar, SAMPLE_EVENTS, CAL_DAYS, CAL_MONTHS });
