// mobile.jsx — single-scroll, sectioned layout for tablet & phone.
// Replaces the old two-tab (Ticket / Job) split, which scattered
// the Scope of Work field and Ticket History selector onto a separate
// tab from the Ticket Type and Schedule they belong with.
//
// Everything lives in ONE continuous scroll, grouped into labeled
// sections, with a sticky "jump to" nav so the long form stays
// navigable without hiding anything.

const MS_SECTIONS = [
  { id: "ticket",   label: "Ticket" },
  { id: "scope",    label: "Scope" },
  { id: "schedule", label: "Schedule" },
  { id: "techs",    label: "Find Tech" },
  { id: "history",  label: "History" },
];

/* ── Ticket History as the scrollable table (matches desktop) ──────────── */
function TicketHistoryTable({ history, selectedId, onSelect }) {
  return (
    <div className="ticket-history">
      <div className="ticket-history-scroll">
        <div className="ticket-history-head">
          <div>Ticket</div><div>Created</div><div>Type</div><div>Problem Code</div>
          <div>Status</div><div>Scheduled</div><div>Closed</div>
        </div>
        {history.map((t) => {
          const isSelected = selectedId === t.num;
          return (
            <div
              className={`ticket-history-row ${isSelected ? "selected" : ""}`}
              key={t.num}
              role="button"
              tabIndex={0}
              onClick={() => onSelect && onSelect(t)}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") onSelect && onSelect(t); }}
            >
              <div className="ticket-num">#{t.num}</div>
              <div>{t.created}</div>
              <div>{t.type}</div>
              <div>{t.problem}</div>
              <div>
                <span className={`pill-status s-${t.status.toLowerCase().replace(" ", "")}`}>{t.status}</span>
              </div>
              <div className="mono">{t.scheduled}</div>
              <div className="mono">{t.closed}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── Compact customer summary — always visible atop the Ticket section ── */
function MobileCustomerCard({ customer, status }) {
  return (
    <div className="ms-cust">
      <div className="ms-cust-row">
        <StatusPill status={status}/>
        <span className="ms-cust-name"><Icon name="user" size={13} color="#64748B"/>{customer.name}</span>
      </div>
      <div className="ms-cust-row ms-cust-contact">
        <span className="mono">{customer.phone}</span>
        <button className="ico-btn" title="Call"><Icon name="phone" size={12}/></button>
        <button className="ico-btn" title="Text"><Icon name="message" size={12}/></button>
      </div>
      <div className="ms-cust-addr">
        <Icon name="map-pin" size={12} color="#94A3B8"/>
        <span>{customer.address}</span>
      </div>
    </div>
  );
}

function MobileStack({
  form, setForm, customer, status,
  onOpenCalendar, onOpenCompletionLog, onSelectTicket,
}) {
  const scrollRef = React.useRef(null);
  const sectionRefs = React.useRef({});
  const animRef = React.useRef(null);
  React.useEffect(() => () => {
    if (animRef.current) {
      cancelAnimationFrame(animRef.current.raf);
      clearTimeout(animRef.current.guard);
    }
  }, []);
  const [active, setActive] = React.useState("ticket");

  // Highlight the chip for whichever section is nearest the top of the scroll.
  // All math in unscaled layout coords (offsetTop/scrollTop) so it stays correct
  // under the viewport simulator's scale() transform.
  const onScroll = React.useCallback(() => {
    const cont = scrollRef.current;
    if (!cont) return;
    const probe = cont.scrollTop + 72;
    let current = MS_SECTIONS[0].id;
    for (const s of MS_SECTIONS) {
      const el = sectionRefs.current[s.id];
      if (el && el.offsetTop <= probe) current = s.id;
    }
    if (cont.scrollTop + cont.clientHeight >= cont.scrollHeight - 4) {
      current = MS_SECTIONS[MS_SECTIONS.length - 1].id;
    }
    setActive(current);
  }, []);

  const jumpTo = React.useCallback((id) => {
    const cont = scrollRef.current;
    const el = sectionRefs.current[id];
    if (!cont || !el) return;
    const target = Math.max(0, el.offsetTop - 12);  // unscaled layout coord
    setActive(id);                                    // immediate chip feedback

    // Cancel any in-flight animation.
    if (animRef.current) {
      cancelAnimationFrame(animRef.current.raf);
      clearTimeout(animRef.current.guard);
      animRef.current = null;
    }
    const start = cont.scrollTop;
    const dist = target - start;
    if (Math.abs(dist) < 2) { cont.scrollTop = target; return; }

    const dur = 380;
    const now = () => (window.performance ? performance.now() : Date.now());
    const t0 = now();
    const ease = (p) => 1 - Math.pow(1 - p, 3);  // easeOutCubic
    const tick = () => {
      const p = Math.min(1, (now() - t0) / dur);
      cont.scrollTop = start + dist * ease(p);
      if (p < 1) {
        animRef.current.raf = requestAnimationFrame(tick);
      } else {
        cont.scrollTop = target;
        animRef.current = null;
      }
    };
    // Guard: if rAF is throttled/paused, snap to the exact target so the
    // jump is never left half-finished.
    const guard = setTimeout(() => {
      if (!animRef.current) return;
      cancelAnimationFrame(animRef.current.raf);
      cont.scrollTop = target;
      cont.dispatchEvent(new Event("scroll"));
      animRef.current = null;
    }, dur + 140);
    animRef.current = { raf: requestAnimationFrame(tick), guard };
  }, []);

  // When a history ticket is chosen, load it AND scroll back up to the
  // Ticket section so the user can see the type/status/date that loaded.
  const handleSelect = React.useCallback((ticket) => {
    onSelectTicket && onSelectTicket(ticket);
    jumpTo("ticket");
  }, [onSelectTicket, jumpTo]);

  const setRef = (id) => (el) => { sectionRefs.current[id] = el; };

  return (
    <div className="mobile-stack">
      <nav className="ms-nav">
        {MS_SECTIONS.map((s) => (
          <button
            key={s.id}
            type="button"
            className={active === s.id ? "active" : ""}
            onClick={() => jumpTo(s.id)}
          >
            {s.label}
          </button>
        ))}
      </nav>

      <div className="ms-scroll" ref={scrollRef} onScroll={onScroll}>
        {/* ── 1. Ticket ───────────────────────────────────────── */}
        <section className="ms-section" ref={setRef("ticket")}>
          <h2 className="ms-h">Ticket</h2>
          <MobileCustomerCard customer={customer} status={status}/>

          <div className="ms-actions">
            <Button variant="primary" size="sm" icon="plus" className="btn-block">Add New</Button>
            <Button variant="secondary" size="sm" icon="copy" className="btn-block">Duplicate</Button>
          </div>

          <Field label="Ticket Type" required cog>
            <Select value={form.ticketType} onChange={(v) => setForm({...form, ticketType: v})} options={TICKET_TYPES}/>
          </Field>
          <Field label="Problem Code" required cog>
            <Select value={form.problemCode} onChange={(v) => setForm({...form, problemCode: v})} options={PROBLEM_CODES}/>
          </Field>
          <Field label="Ticket Status" cog>
            <Select value={form.ticketStatus} onChange={(v) => setForm({...form, ticketStatus: v})} options={TICKET_STATUSES}/>
          </Field>
          <Field label="Resolution Description" cog>
            <Select value={form.resolution} onChange={(v) => setForm({...form, resolution: v})} options={RESOLUTIONS}/>
          </Field>
          <div className="ms-inline-check">
            <Check checked={form.showActive} onChange={(v) => setForm({...form, showActive: v})} label="Show Active only"/>
          </div>
          <Field label="Assign Ticket">
            <Select value={form.assigned} onChange={(v) => setForm({...form, assigned: v})} options={ASSIGN_OPTIONS}/>
          </Field>
        </section>

        {/* ── 2. Scope of Work ────────────────────────────────── */}
        <section className="ms-section" ref={setRef("scope")}>
          <h2 className="ms-h">Scope &amp; Work</h2>
          <Field label={<span>Scope of Work <span className="muted ms-1">· filled by scheduler</span></span>} required>
            <Textarea value={form.scope} onChange={(v) => setForm({...form, scope: v})} rows={5}
              placeholder="Describe what needs to be done on-site…"/>
          </Field>
          <Field label={<span>Work Performed <span className="muted ms-1">· filled by tech</span></span>} className="mt-4">
            <Textarea value={form.work} onChange={(v) => setForm({...form, work: v})} rows={4}
              placeholder="Filled by tech on completion"/>
          </Field>
        </section>

        {/* ── 3. Schedule ─────────────────────────────────────── */}
        <section className="ms-section" ref={setRef("schedule")}>
          <h2 className="ms-h">Schedule</h2>
          <div className="card card-pad">
            <Field label="Date">
              <Input value={form.date} onChange={(v) => setForm({...form, date: v})} icon="calendar" placeholder="mm/dd/yyyy"/>
            </Field>
            <div className="field-row cols-2 mt-4">
              <Field label="Start Time">
                <Input value={form.start} onChange={(v) => setForm({...form, start: v})} icon="clock" placeholder="hh:mm tt"/>
              </Field>
              <Field label="End Time">
                <Input value={form.end} onChange={(v) => setForm({...form, end: v})} icon="clock" placeholder="hh:mm tt"/>
              </Field>
            </div>
            <div className="mt-3">
              <Check checked={form.multiDay} onChange={(v) => setForm({...form, multiDay: v})} label="Multi-Day Ticket"/>
            </div>
            <Field label="Time Zone" className="mt-3">
              <Select value={form.tz} onChange={(v) => setForm({...form, tz: v})} options={TIME_ZONES}/>
            </Field>
          </div>
          <Button variant="secondary" icon="calendar" onClick={onOpenCalendar} className="btn-block mt-4">
            View Full Calendar
          </Button>
          <Button variant="secondary" icon="map-pin" className="btn-block mt-2">
            View Techs on Map
          </Button>
          <div className="mt-5">
            <CompletionLogBlock onOpenCompletionLog={onOpenCompletionLog}/>
          </div>
        </section>

        {/* ── 4. Find a Tech ──────────────────────────────────── */}
        <section className="ms-section" ref={setRef("techs")}>
          <h2 className="ms-h">Find a Tech</h2>
          <div className="ms-subtle">Site Specifications</div>
          <div className="stat-tiles">
            {STAT_TILES.map((s) => (
              <div className="stat-tile" key={s.label}>
                <span className="stat-label">{s.label}</span>
                <span className={`stat-value ${s.value === "-" ? "dash" : ""}`}>{s.value}</span>
              </div>
            ))}
          </div>
          <div className="ms-tech-search mt-4">
            <Field label="City">
              <Input value={form.city} onChange={(v) => setForm({...form, city: v})} icon="map-pin" placeholder="City"/>
            </Field>
            <Field label="Date Range">
              <Input value={form.dateRange} onChange={(v) => setForm({...form, dateRange: v})} icon="calendar"/>
            </Field>
            <Field label="Search techs by city">
              <Input value={form.techSearch || ""} onChange={(v) => setForm({...form, techSearch: v})} icon="search" placeholder="e.g. Dallas"/>
            </Field>
            <Button variant="primary" icon="search" className="btn-block">Search</Button>
          </div>
          <div className="ms-subtle mt-5">Available Techs</div>
          <div className="tech-grid">
            <div className="tech-grid-row">
              <div className="name"><span className="avatar">RF</span> Ryan Fitzgerald</div>
              <div>Arvada, CO</div>
              <div className="mono">May 27 · 7:30 AM</div>
              <div><Icon name="more" size={14}/></div>
            </div>
            <div className="tech-grid-row">
              <div className="name"><span className="avatar t2">CD</span> Christopher Diaz</div>
              <div>Denver, CO</div>
              <div className="mono">May 28 · 9:00 AM</div>
              <div><Icon name="more" size={14}/></div>
            </div>
            <div className="tech-grid-row">
              <div className="name"><span className="avatar t3">JC</span> James Carter</div>
              <div>Longmont, CO</div>
              <div className="mono">May 30 · 12:00 PM</div>
              <div><Icon name="more" size={14}/></div>
            </div>
          </div>
        </section>

        {/* ── 5. Ticket History ───────────────────────────────── */}
        <section className="ms-section" ref={setRef("history")}>
          <div className="ms-h-row">
            <h2 className="ms-h">Ticket History</h2>
            <span className="ms-hist-sub">This customer · tap to edit</span>
            <div className="ms-hist-filter">
              <Check checked={form.voided} onChange={(v) => setForm({...form, voided: v})} label="Voided"/>
            </div>
          </div>
          <TicketHistoryTable history={TICKET_HISTORY} selectedId={form.selectedTicketId} onSelect={handleSelect}/>
        </section>

        <div className="ms-foot-pad"/>
      </div>
    </div>
  );
}

Object.assign(window, { MobileStack, TicketHistoryTable, MobileCustomerCard, MS_SECTIONS });
