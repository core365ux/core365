// scheduling.jsx — Scheduling screen components.
// Layout uses Bootstrap utility classes + custom design-system classes.
// No inline `style={{}}` blocks.

const TICKET_TYPES = ["Installation", "Service Call", "Inspection", "Maintenance", "Removal", "Re-Roof"];
const PROBLEM_CODES = [
  "Inverter Fault", "Panel Replacement", "Production Issue",
  "Roof Leak", "Wiring", "Monitoring Setup", "Permit Inspection",
  "Reconnect", "Upgrade",
];
const TICKET_STATUSES = ["Open", "Scheduled", "In Progress", "On Hold", "Completed", "Cancelled"];
const RESOLUTIONS = ["Resolved on Site", "Pending Parts", "Customer Reschedule", "Escalated", "No Issue Found"];
const ASSIGN_OPTIONS = ["Ryan Fitzgerald", "Christopher Diaz", "Maria Lopez", "James Carter", "Aaron Walsh"];
const OFFICES = ["Dallas", "Denver", "Phoenix", "Sacramento", "Austin"];
const TECHS = ["Ryan Fitzgerald", "Christopher Diaz", "James Carter", "Aaron Walsh", "Maria Lopez", "Jordan Reyes"];
const TIME_ZONES = [
  "America/Chicago", "America/New_York", "America/Denver",
  "America/Los_Angeles", "America/Phoenix",
];

const STAT_TILES = [
  { label: "Panels", value: "32" },
  { label: "Size (kW)", value: "13.12" },
  { label: "Stories", value: "-" },
  { label: "Vaulted", value: "-" },
  { label: "Arrays", value: "-" },
  { label: "Pitch", value: "-" },
];

const RELATED_LINKS = [
  { label: "Project", icon: "external" },
  { label: "HOA", icon: "external" },
  { label: "AHJ", icon: "external" },
  { label: "Utility", icon: "external" },
];

const TICKET_HISTORY = [
  { num: "217", created: "05/26/2026", type: "Installation", problem: "Inverter Setup", status: "Completed", scheduled: "05/26/2026", closed: "06/08/2026" },
  { num: "204", created: "04/12/2026", type: "Service Call",  problem: "Panel Replacement", status: "Completed", scheduled: "04/12/2026", closed: "04/14/2026" },
  { num: "189", created: "02/03/2026", type: "Inspection",    problem: "Permit Inspection", status: "Completed", scheduled: "02/04/2026", closed: "02/04/2026" },
  { num: "162", created: "11/19/2025", type: "Maintenance",   problem: "Production Issue",  status: "Scheduled", scheduled: "11/22/2025", closed: "-" },
];

const COMPLETION_STEPS = [
  { name: "Arrived",    time: "8:14 AM",  done: true, lat: 32.7466, lng: -96.8388, addr: "719 S Rosemont Ave, Dallas, TX" },
  { name: "Departed",   time: "12:47 PM", done: true, lat: 32.7468, lng: -96.8391, addr: "719 S Rosemont Ave, Dallas, TX" },
  { name: "Completed",  time: "12:48 PM", done: true, lat: 32.7468, lng: -96.8391, addr: "719 S Rosemont Ave, Dallas, TX" },
];

/* ───────────────────────── Customer header ───────────────────────── */
const CustomerHeader = ({ customer, status, form, setForm, onOpenCalendar }) => (
  <div className="sched-header">
    <StatusPill status={status}/>
    <div className="header-divider"/>

    <div className="cust-block">
      <div className="cust-name">
        <Icon name="user" size={14} color="#64748B"/>
        {customer.name}
      </div>
      <div className="cust-meta">
        <span><span className="label">Phone</span>{customer.phone}</span>
        <button className="ico-btn" title="Call"><Icon name="phone" size={11}/></button>
        <button className="ico-btn" title="Text"><Icon name="message" size={11}/></button>
      </div>
      <div className="cust-meta cust-addr">
        <Icon name="map-pin" size={12} color="#94A3B8"/>
        <span>{customer.address}</span>
      </div>
    </div>

    <div className="header-divider"/>
    <div className="header-flags">
      <Check tone="success" checked={form.nextDay}
        onChange={(v) => setForm({...form, nextDay: v})} label="Next Day Schedule"/>
      <Check tone="success" checked={form.midPoint}
        onChange={(v) => setForm({...form, midPoint: v})} label="Mid-Point Req"/>
    </div>
    <Button variant="ghost" size="sm" icon="calendar" onClick={onOpenCalendar}>Open Calendar</Button>
  </div>
);

/* ───────────────────────── Subhead helper ───────────────────────── */
const Subhead = ({ title, meta, children }) => (
  <div className="subhead">
    <h3>
      {title}
      {meta && <span className="sub-meta ms-2">· {meta}</span>}
    </h3>
    {children}
  </div>
);

/* ───────────────────────── Ticket meta (reused in App's TicketMetaInner shape) ───────────────────────── */
const TicketMetaBody = ({ form, setForm, onOpenCompletionLog }) => (
  <React.Fragment>
    <div className="d-flex gap-1 mb-3 btn-equal">
      <Button variant="primary" size="sm" icon="plus">Add New</Button>
      <Button variant="secondary" size="sm" icon="copy">Duplicate</Button>
    </div>

    <div className="divider-line"/>

    <Field label="Ticket Type" required cog>
      <Select value={form.ticketType} onChange={(v) => setForm({...form, ticketType: v})} options={TICKET_TYPES}/>
    </Field>
    <Field label="Problem Code" required cog>
      <Select value={form.problemCode} onChange={(v) => setForm({...form, problemCode: v})} options={PROBLEM_CODES}/>
    </Field>
    <Field label="Ticket Status" cog>
      <Select value={form.ticketStatus} onChange={(v) => setForm({...form, ticketStatus: v})} options={TICKET_STATUSES}/>
    </Field>
    <Field label="Resolution Description" cog>
      <Select value={form.resolution} onChange={(v) => setForm({...form, resolution: v})} options={RESOLUTIONS}/>
    </Field>

    <div className="mt-2 mb-2">
      <Check checked={form.showActive} onChange={(v) => setForm({...form, showActive: v})} label="Show Active only"/>
    </div>

    <Field label="Assign Ticket">
      <Select value={form.assigned} onChange={(v) => setForm({...form, assigned: v})} options={ASSIGN_OPTIONS}/>
    </Field>
  </React.Fragment>
);

/* ───────────────────────── Completion log block (reusable) ───────────────────────── */
const CompletionLogBlock = ({ onOpenCompletionLog }) => (
  <div className="completion-log">
    <div className="clog-head">
      <span>Completion Log</span>
      <a className="clog-link" onClick={onOpenCompletionLog}>Open <Icon name="external" size={10}/></a>
    </div>
    {COMPLETION_STEPS.map((s) => (
      <div key={s.name} className={`clog-row ${s.done ? "done" : ""}`}>
        <span className="clog-status">{s.done && <Icon name="check" size={9} stroke={2.5}/>}</span>
        <span className="clog-name">{s.name}</span>
        <span className="clog-time">{s.time}</span>
        <button
          className="clog-geo"
          disabled={!s.done}
          title={s.done ? `Check-in at ${s.lat.toFixed(4)}, ${s.lng.toFixed(4)} — ${s.addr}` : "No location yet"}
          onClick={() => s.done && alert(`Map view\n\n${s.name} at ${s.time}\n${s.addr}\n${s.lat}, ${s.lng}`)}
        >
          <Icon name="globe" size={13}/>
        </button>
      </div>
    ))}
  </div>
);

/* ───────────────────────── Middle column: Job + Activity ───────────────────────── */
const JobColumn = ({ form, setForm, onOpenCalendar, onSelectTicket, customer, status }) => (
  <React.Fragment>
    {/* Context strip: customer + ticket flags + calendar shortcut */}
    <div className="job-context">
      <StatusPill status={status}/>
      <div className="header-divider"/>
      <div className="cust-block">
        <div className="cust-name">
          <Icon name="user" size={14} color="#64748B"/>
          {customer.name}
        </div>
        <div className="cust-meta">
          <span>{customer.phone}</span>
          <button className="ico-btn" title="Call"><Icon name="phone" size={11}/></button>
          <button className="ico-btn" title="Text"><Icon name="message" size={11}/></button>
        </div>
        <div className="cust-meta cust-addr">
          <Icon name="map-pin" size={12} color="#94A3B8"/>
          <span>{customer.address}</span>
        </div>
      </div>
      <div className="header-flags ms-auto">
        <Check tone="success" checked={form.nextDay}
          onChange={(v) => setForm({...form, nextDay: v})} label="Next Day Schedule"/>
        <Check tone="success" checked={form.midPoint}
          onChange={(v) => setForm({...form, midPoint: v})} label="Mid-Point Req"/>
      </div>
    </div>

    {/* Site stats */}
    <Subhead title="Site Specifications">
      <span className="sub-meta">From project intake</span>
    </Subhead>
    <div className="stat-tiles">
      {STAT_TILES.map((t) => (
        <div className="stat-tile" key={t.label}>
          <span className="stat-label">{t.label}</span>
          <span className={`stat-value ${t.value === "-" ? "dash" : ""}`}>{t.value}</span>
        </div>
      ))}
    </div>

    {/* Search row */}
    <div className="divider-line"/>
    <Subhead title="Job Details"/>
    <div className="job-search-row">
      <Field label="City">
        <Input value={form.city} onChange={(v) => setForm({...form, city: v})} icon="map-pin" placeholder="City"/>
      </Field>
      <Field label="Date Range">
        <Input value={form.dateRange} onChange={(v) => setForm({...form, dateRange: v})} icon="calendar"/>
      </Field>
      <Field label="Search techs by city">
        <Input value={form.techSearch || ""} onChange={(v) => setForm({...form, techSearch: v})} icon="search" placeholder="e.g. Dallas"/>
      </Field>
      <Field label={<span className="label-blank"/>}>
        <Button variant="primary" icon="search" className="h-ctrl">Search</Button>
      </Field>
    </div>

    {/* Available techs */}
    <div className="subhead mt-5">
      <h3>Available Techs</h3>
    </div>
    <div className="tech-grid">
      <div className="tech-grid-head">
        <div>Tech</div><div>City</div><div>Next Available</div><div></div>
      </div>
      <div className="tech-grid-row">
        <div className="name"><span className="avatar">RF</span> Ryan Fitzgerald</div>
        <div>Arvada, CO</div>
        <div className="mono">May 27 · 7:30 AM</div>
        <div><Icon name="more" size={14}/></div>
      </div>
      <div className="tech-grid-row">
        <div className="name"><span className="avatar t2">CD</span> Christopher Diaz</div>
        <div>Denver, CO</div>
        <div className="mono">May 28 · 9:00 AM</div>
        <div><Icon name="more" size={14}/></div>
      </div>
      <div className="tech-grid-row">
        <div className="name"><span className="avatar t3">JC</span> James Carter</div>
        <div>Longmont, CO</div>
        <div className="mono">May 30 · 12:00 PM</div>
        <div><Icon name="more" size={14}/></div>
      </div>
    </div>

    {/* Scope (scheduler) + Work performed (tech) — side by side on desktop */}
    <div className="scope-work-grid mt-5">
      <Field label={<span>Scope of Work <span className="muted ms-1">· filled by scheduler</span></span>} required>
        <Textarea value={form.scope} onChange={(v) => setForm({...form, scope: v})}
          rows={4}
          placeholder="Describe what needs to be done on-site…"/>
      </Field>
      <Field label={<span>Work Performed <span className="muted ms-1">· filled by tech on completion</span></span>}>
        <Textarea value={form.work} onChange={(v) => setForm({...form, work: v})}
          rows={4}
          placeholder="Filled by tech on completion"/>
      </Field>
    </div>

    {/* Ticket history */}
    <div className="subhead mt-5">
      <h3>Ticket History <span className="sub-meta ms-2">· This customer</span></h3>
      <div className="d-flex align-items-center gap-4">
        <Check checked={form.voided} onChange={(v) => setForm({...form, voided: v})} label="Show voided tickets"/>
        <Button variant="ghost" size="sm" icon="filter">Filter</Button>
      </div>
    </div>
    <div className="ticket-history">
      <div className="ticket-history-scroll">
        <div className="ticket-history-head">
          <div>Ticket</div><div>Created</div><div>Type</div><div>Problem Code</div>
          <div>Status</div><div>Scheduled</div><div>Closed</div>
        </div>
        {TICKET_HISTORY.map((t) => {
          const isSelected = form.selectedTicketId === t.num;
          return (
            <div
              className={`ticket-history-row ${isSelected ? "selected" : ""}`}
              key={t.num}
              role="button"
              tabIndex={0}
              onClick={() => onSelectTicket && onSelectTicket(t)}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") onSelectTicket && onSelectTicket(t); }}
            >
              <div className="ticket-num">#{t.num}</div>
              <div>{t.created}</div>
              <div>{t.type}</div>
              <div>{t.problem}</div>
              <div>
                <span className={`pill-status s-${t.status.toLowerCase().replace(" ", "")}`}>
                  {t.status}
                </span>
              </div>
              <div className="mono">{t.scheduled}</div>
              <div className="mono">{t.closed}</div>
            </div>
          );
        })}
      </div>
    </div>
  </React.Fragment>
);

/* ───────────────────────── Right column: Schedule ───────────────────────── */
const ScheduleColumn = ({ form, setForm, onOpenCalendar, onOpenCompletionLog, calendarMode, calState, calActions }) => (
  <React.Fragment>
    <Subhead title="Assign Schedule"/>

    <div className="card card-pad">
      <Field label="Date">
        <Input value={form.date} onChange={(v) => setForm({...form, date: v})} icon="calendar" placeholder="mm/dd/yyyy"/>
      </Field>
      <div className="field-row cols-2 mt-4">
        <Field label="Start Time">
          <Input value={form.start} onChange={(v) => setForm({...form, start: v})} icon="clock" placeholder="hh:mm tt"/>
        </Field>
        <Field label="End Time">
          <Input value={form.end} onChange={(v) => setForm({...form, end: v})} icon="clock" placeholder="hh:mm tt"/>
        </Field>
      </div>

      <div className="mt-3">
        <Check checked={form.multiDay} onChange={(v) => setForm({...form, multiDay: v})} label="Multi-Day Ticket"/>
      </div>

      <Field label="Time Zone" className="mt-3">
        <Select value={form.tz} onChange={(v) => setForm({...form, tz: v})} options={TIME_ZONES}/>
      </Field>
    </div>

    {/* Inline calendar mode */}
    {calendarMode === "inline" && (
      <div className="card overflow-hidden mt-5">
        <Calendar
          {...calState}
          {...calActions}
          compact={true}
        />
      </div>
    )}

    {calendarMode !== "inline" && (
      <Button variant="secondary" icon="calendar" onClick={onOpenCalendar} className="w-100 mt-5">
        View Full Calendar
      </Button>
    )}

    <Button variant="secondary" icon="map-pin" className="w-100 mt-2">
      View Techs on Map
    </Button>

    <div className="mt-5">
      <CompletionLogBlock onOpenCompletionLog={onOpenCompletionLog}/>
    </div>
  </React.Fragment>
);

/* ───────────────────────── Completion Log modal ───────────────────────── */
const CompletionLogModal = ({ open, onClose, value, onChange, onSave }) => {
  const fields = [
    { key: "arrived",   label: "Arrival Date / Time" },
    { key: "departed",  label: "Departure Date / Time" },
    { key: "completed", label: "Completed Date / Time" },
  ];
  const showLocation = (key, label) => {
    const v = value[key];
    if (!v?.date) return;
    alert(`Map view\n\n${label} at ${v.date} ${v.time}\n${v.lat || "32.7466"}, ${v.lng || "-96.8388"}\n719 S Rosemont Ave, Dallas, TX`);
  };
  return (
    <div className={`modal-scrim ${open ? "open" : ""}`} onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h2>Completion Log</h2>
          <button className="close-x" onClick={onClose} aria-label="Close">
            <Icon name="x" size={14}/>
          </button>
        </div>
        <div className="modal-body">
          {fields.map((f, i) => (
            <Field label={
              <span className="d-flex align-items-center w-100">
                {f.label}
                <button
                  type="button"
                  className="clog-geo ms-auto"
                  title="View check-in location"
                  onClick={() => showLocation(f.key, f.label)}
                  disabled={!value[f.key]?.date}
                >
                  <Icon name="globe" size={13}/>
                </button>
              </span>
            } key={f.key} className={i > 0 ? "mt-4" : ""}>
              <div className="dt-pair">
                <Input
                  icon="calendar"
                  placeholder="mm/dd/yyyy"
                  value={value[f.key]?.date || ""}
                  onChange={(v) => onChange({...value, [f.key]: {...value[f.key], date: v}})}
                />
                <Input
                  icon="clock"
                  placeholder="hh:mm tt"
                  value={value[f.key]?.time || ""}
                  onChange={(v) => onChange({...value, [f.key]: {...value[f.key], time: v}})}
                />
              </div>
            </Field>
          ))}
        </div>
        <div className="modal-foot">
          <Button variant="secondary" icon="x" onClick={onClose}>Close</Button>
          <Button variant="success" icon="check" onClick={onSave}>Save</Button>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, {
  CustomerHeader, TicketMetaBody, CompletionLogBlock, JobColumn, ScheduleColumn, CompletionLogModal, Subhead,
  TICKET_TYPES, PROBLEM_CODES, TICKET_STATUSES, RESOLUTIONS, ASSIGN_OPTIONS,
  OFFICES, TECHS, TIME_ZONES, STAT_TILES, RELATED_LINKS, TICKET_HISTORY, COMPLETION_STEPS,
});
