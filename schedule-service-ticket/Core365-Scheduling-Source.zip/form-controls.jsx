// form-controls.jsx — primitives shared across the scheduling screen.
// Plain JSX, no external deps. Exports onto window for other Babel scripts.

const Icon = ({ name, size = 14, stroke = 1.6, color = "currentColor", ...rest }) => {
  const common = {
    width: size, height: size, viewBox: "0 0 24 24",
    fill: "none", stroke: color, strokeWidth: stroke,
    strokeLinecap: "round", strokeLinejoin: "round",
    ...rest,
  };
  switch (name) {
    case "calendar": return (
      <svg {...common}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></svg>
    );
    case "clock": return (
      <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
    );
    case "phone": return (
      <svg {...common}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
    );
    case "message": return (
      <svg {...common}><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
    );
    case "map-pin": return (
      <svg {...common}><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
    );
    case "search": return (
      <svg {...common}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>
    );
    case "x": return (
      <svg {...common}><path d="M18 6 6 18M6 6l12 12"/></svg>
    );
    case "chevron-left": return (
      <svg {...common}><path d="M15 18 9 12l6-6"/></svg>
    );
    case "chevron-right": return (
      <svg {...common}><path d="M9 18l6-6-6-6"/></svg>
    );
    case "chevron-down": return (
      <svg {...common}><path d="M6 9l6 6 6-6"/></svg>
    );
    case "chevron-up": return (
      <svg {...common}><path d="M18 15l-6-6-6 6"/></svg>
    );
    case "plus": return (
      <svg {...common}><path d="M12 5v14M5 12h14"/></svg>
    );
    case "edit": return (
      <svg {...common}><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
    );
    case "copy": return (
      <svg {...common}><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
    );
    case "external": return (
      <svg {...common}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14L21 3"/></svg>
    );
    case "settings": return (
      <svg {...common}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
    );
    case "user": return (
      <svg {...common}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
    );
    case "more": return (
      <svg {...common}><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
    );
    case "globe": return (
      <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>
    );
    case "filter": return (
      <svg {...common}><path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z"/></svg>
    );
    case "check": return (
      <svg {...common}><path d="M20 6L9 17l-5-5"/></svg>
    );
    case "save": return (
      <svg {...common}><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/></svg>
    );
    case "info": return (
      <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/></svg>
    );
    case "layers": return (
      <svg {...common}><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
    );
    default: return null;
  }
};

/* ───────────────────────── Field wrapper ───────────────────────── */
const Field = ({ label, required, hint, children, className = "", cog, onCog }) => (
  <div className={`field ${className}`}>
    {label && (
      <div className="label-row">
        <label className="label">
          {label}{required && <span className="req">*</span>}
          {hint && <span className="hint">{hint}</span>}
        </label>
        {cog && (
          <button type="button" className="field-cog" aria-label={`${label} settings`} onClick={onCog}>
            <Icon name="settings" size={15} />
          </button>
        )}
      </div>
    )}
    {children}
  </div>
);

/* ───────────────────────── Input ───────────────────────── */
const Input = ({ icon, value, onChange, placeholder, type = "text", ...rest }) => {
  const el = (
    <input
      type={type}
      className="input"
      value={value || ""}
      onChange={(e) => onChange && onChange(e.target.value)}
      placeholder={placeholder}
      {...rest}
    />
  );
  if (icon) {
    return (
      <div className="input-with-icon">
        <span className="ico"><Icon name={icon} size={14} /></span>
        {el}
      </div>
    );
  }
  return el;
};

/* ───────────────────────── Select ───────────────────────── */
const Select = ({ value, onChange, options = [], placeholder = "Select", ...rest }) => (
  <select
    className="select"
    value={value || ""}
    onChange={(e) => onChange && onChange(e.target.value)}
    {...rest}
  >
    <option value="" disabled>{placeholder}</option>
    {options.map((o) =>
      typeof o === "string"
        ? <option key={o} value={o}>{o}</option>
        : <option key={o.value} value={o.value}>{o.label}</option>
    )}
  </select>
);

/* ───────────────────────── Textarea ───────────────────────── */
const Textarea = ({ value, onChange, placeholder, rows = 4, ...rest }) => (
  <textarea
    className="textarea"
    value={value || ""}
    onChange={(e) => onChange && onChange(e.target.value)}
    placeholder={placeholder}
    rows={rows}
    {...rest}
  />
);

/* ───────────────────────── Check ───────────────────────── */
const Check = ({ checked, onChange, label, tone = "default" }) => (
  <label className={`check check-${tone}`}>
    <input type="checkbox" checked={!!checked} onChange={(e) => onChange && onChange(e.target.checked)} />
    <span>{label}</span>
  </label>
);

/* ───────────────────────── Button ───────────────────────── */
const Button = ({ variant = "secondary", size, icon, iconRight, className = "", children, ...rest }) => {
  const cls = ["btn", `btn-${variant}`, size && `btn-${size}`, className].filter(Boolean).join(" ");
  return (
    <button className={cls} {...rest}>
      {icon && <Icon name={icon} size={14} />}
      {children}
      {iconRight && <Icon name={iconRight} size={14} />}
    </button>
  );
};

/* ───────────────────────── Status pill ───────────────────────── */
const StatusPill = ({ status }) => {
  const cls = `status-pill status-${status.toLowerCase()}`;
  return (
    <span className={cls}>
      <span className="dot"/>
      {status}
    </span>
  );
};

/* ───────────────────────── Segmented control ───────────────────────── */
const Segmented = ({ value, onChange, options }) => (
  <div className="segmented">
    {options.map((opt) => {
      const o = typeof opt === "string" ? { value: opt, label: opt } : opt;
      return (
        <button
          key={o.value}
          className={value === o.value ? "active" : ""}
          onClick={() => onChange && onChange(o.value)}
        >{o.label}</button>
      );
    })}
  </div>
);

Object.assign(window, {
  Icon, Field, Input, Select, Textarea, Check, Button, StatusPill, Segmented,
});
